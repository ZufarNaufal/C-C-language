#include<iostream>
	#include<stdio.h>
		#include<conio.h>
			#include<ctime>
				#include<windows.h>
					#include<stdlib.h>
						#include<fstream>
							#include<iomanip>
								#define max 100
using namespace std;


int menu=0;
	char date[10];
		int Age[10],nim[20],kode['0'],a=0,b,d,e=151200;
			int i,j,k,pilih;
				char cari[20], keluar;
					


//char format[]="NPM & NAME";
//ar firstName[30],lastName[30],Prodi[50],Address[50],FileName[50];



FILE *input;


void MHS_menu();
	void cetak();
		void find_DT();
			void layout();
				void inputDT_MHS();
					void EXIT();

struct mahasiswa {
	char nama[50],nim[20],prodi[20],ipk[10];
	int hasiltes[20];
};mahasiswa mhs[max];

struct sort_mhs
{
    //char mhs;
    string nama[40];
    int hasiltes[20];


};
//void struct mahasiswa()
//{
		
//}


void loadingScreen(char*text)
{
	cout<<"\n";
            cout<<"\t\t\t\t "<< text << "\n\n";
            for(int o = 0; o<26;o++)
                   {
                        cout <<(unsigned char)220<<(unsigned char)219<<(unsigned char)223;
                        cout <<(unsigned char)220<<(unsigned char)219<<(unsigned char)223;
                        cout <<(unsigned char)220<<(unsigned char)219<<(unsigned char)223;
                        cout <<(unsigned char)220<<(unsigned char)219<<(unsigned char)223;
                        cout <<(unsigned char)220<<(unsigned char)219<<(unsigned char)223;
                        cout <<(unsigned char)220<<(unsigned char)219<<(unsigned char)223;
                        cout <<(unsigned char)220<<(unsigned char)219<<(unsigned char)223;
                        cout <<(unsigned char)220<<(unsigned char)219<<(unsigned char)223;
                        cout <<(unsigned char)220<<(unsigned char)219<<(unsigned char)223;
                        cout <<(unsigned char)220<<(unsigned char)219<<(unsigned char)223;
                        Sleep(50)
						;
                        system("color 0c");
                        cout <<(unsigned char)220<<(unsigned char)219<<(unsigned char)223;
                        cout <<(unsigned char)220<<(unsigned char)219<<(unsigned char)223;
                        cout <<(unsigned char)220<<(unsigned char)219<<(unsigned char)223;
                        cout <<(unsigned char)220<<(unsigned char)219<<(unsigned char)223;
                        cout <<(unsigned char)220<<(unsigned char)219<<(unsigned char)223;
                        cout <<(unsigned char)220<<(unsigned char)219<<(unsigned char)223;
                        cout <<(unsigned char)220<<(unsigned char)219<<(unsigned char)223;
                        cout <<(unsigned char)220<<(unsigned char)219<<(unsigned char)223;
                        cout <<(unsigned char)220<<(unsigned char)219<<(unsigned char)223;
                        cout <<(unsigned char)220<<(unsigned char)219<<(unsigned char)223;
                        Sleep(30);
                    }	
				}

void DB();
void login(){
	 system("UniversitasPakuan - Login Administrator");
     DB;
     char uname[12];
     char pass[5];
     loginku:

             system("cls");
             system("color 0C");
             cout<<"\n\n\n"<<endl;
             cout<<"\t\t\t\t	    	UNIVERSITAS PAKUAN"<<endl;
             cout<<"\t\t\t\t    !===========================================!"<<endl;
             cout<<"\t\t\t\t    |-------==	Universitas Pakuan  ===---------| "<<endl;
             cout<<"\t\t\t\t    |----------------LOGIN FORM-----------------| "<<endl;
             cout<<"\t\t\t\t    |___________________________________________|"<<endl;
			 cout<<"\t\t\t                            "<<endl;
			 cout<<"\t\t\t	USERNAME	: ";cin>>uname;
			 cout<<"\t\t\t	PASSWORD	: ";cin>>pass;
			 if(strcmp(uname,"RTX-CORE")==0 && strcmp(pass,"****")==0){
                               loadingScreen("Ready For Setup");
                               system("cls");
                               //mainMenu();
                               }else{
                                     cout<<"Login gagal"<<endl;
                                     goto loginku;
                                     }
}


 
    

void list_mhsw()
{	

	
	printf("\n\n			----- LIST MAHASISWA UNPAK ------ \n");
	printf("\n=============================================================");
	printf("\n||	NPM 		||			NAMA			|| 	KELAS	||	");
	printf("\n=============================================================");	
	printf("\n||	0651181 	||			a			|| 	E-F		||	");	
	printf("\n||	0651181		||			b			|| 	E-F		||	");	
	printf("\n||	0651181		||			b			|| 	E-F		||	");	
	printf("\n||	0651181		||			b			|| 	E-F		||	");	
	printf("\n||	0651181		||			b			|| 	E-F		||	");	
	printf("\n||	0651181		||			b			|| 	E-F		||	");	
	printf("\n||	0651181		||			b			|| 	E-F		||	");	
	printf("\n||	0651181		||			b			|| 	E-F		||	");	
	printf("\n||	0651181		||			b			|| 	E-F		||	");	
	printf("\n||	0651181		||			b			|| 	E-F		||	");	
	printf("\n||	0651181		||			b			|| 	E-F		||	");	
	printf("\n||	0651181		||			b			|| 	E-F		||	");	
	printf("\n||	0651181		||			b			|| 	E-F		||	");	
	
	printf("\n ketik 1 untuk input lagi ketik 0 untuk kembali ke tampilan menu : ");
    scanf("%d",&b);	
    system("cls");
    
}

void EXIT(){
	printf("\n\n");
	printf("\t\t--------------		Thanks For Visit		-------------------\n");
	printf("\n\n");
}

void MHS_menu(){
	begin:
	cout<<"\t\t\t\t	    	UNIVERSITAS PAKUAN"<<endl;
    cout<<"\t\t\t\t    !===========================================!"<<endl;
    cout<<"\t\t\t\t    |-------==	Universitas Pakuan  ===---------| "<<endl;
    cout<<"\t\t\t\t    |-------------FORM INPUT DATA--------------| "<<endl;
    cout<<"\t\t\t\t    |___________________________________________|"<<endl;
	cout<<"\t\t\t                            \n\n"<<endl;
			 
	cout<<"\n\nPilihan\n"<<endl;
	
	cout<<"1. Input Data"<<endl;
	cout<<"2. tampil data"<<endl;
	cout<<"3. pencarian npm"<<endl;
	cout<<"4. cetak file txt"<<endl;
	cout<<"5. Exit"<<endl;
	cout<<"pilih (1-5) : "; cin>>pilih;
	system("cls");
	switch(pilih)
	{
		case 1 : 
			cout<<"masukkan jumlah data : "; cin>>j;
			cout<<endl<<endl;
			cin.ignore();
			inputDT_MHS();
			 goto begin;
		
	case 2 : 
			cout<<"\n\n MAHASISWA : \n\n";
			layout();
			  goto begin;
		
	case 3 : 
			find_DT();
			  goto begin;
		
	case 4 : 
			cetak();
			  goto begin;
		
	case 5 :
			cout<<"ingin keluar (y/n) :";
			cin>>keluar;
			if(keluar == 'y' || keluar == 'Y')
			{
				EXIT();
				exit(0);
			} 
			else {
				 goto begin;
			}
		default : cout<<"\n Pilihan tidak tersedia";
			  goto begin;
		}
	  
}

void find_DT(){
	k=0;
	cout<<"\nCari NPM : "; cin>>cari;
	for(i=1; i<=j; i++)
	{
		if(strcmp(cari,mhs[i].nim))
		{
			cout<<"\n\n==============================================\n"<<endl;
			cout<<"\nNPM Ditemukan Di data Ke-"<<i<<"Atas Nama"<<mhs[i].nama<<endl;
			k++;
		}
	}
	if (k!=0)
	{
		cout<<"jumlah NPM Yang Ditemukan" <<k<<" NPM ";
		cout<<"\n\n======================================\n\n"<<endl;
	}
	else 
	{
		cout<<"NPM Tidak Ditemukan";
	}
	
}

void slct(){
	
}

void inputDT_MHS()
    {
       for (i=1; i<=j; i++)
	   {
	   		cout<<"\n======================================\n\n";
	   		cout<<"Data Ke-"<<i<<"\n";
	   		cout<<"Input Nama :"; cin.getline(mhs[i].nama,sizeof (mhs[i].nama));
	   		cout<<"Input NPM :"; cin.getline(mhs[i].nim,sizeof (mhs[i].nim));
	   		cout<<"Input Program Studi :"; cin.getline(mhs[i].prodi,sizeof (mhs[i].prodi));
	   		cout<<"Input Ipk :"; cin.getline(mhs[i].ipk,sizeof (mhs[i].ipk));
	   }
	   system("cls");
}


void layout()
{
	system("cls");
	for (i=1; i<=j; i++)
	{
		cout<<"Data Mahasiswa Ke-"<<i<<endl;
		cout<<"Nama\t : "<<mhs[i].nama<<endl;
		cout<<"NPM\t : "<<mhs[i].nim<<endl;
		cout<<"Program Studi\t : "<<mhs[i].prodi<<endl;
		cout<<"IPK\t : \n"<<mhs[i].ipk<<endl;
	}
}
void cetak()
{
	
    loadingScreen("Waiting For Printing...");
	ofstream file_keluaran;
	file_keluaran.open("Data Mahasiswa.pdf");
	system("cls");
	cout<<"Berhasil dicetak.."<<endl<<"Silahkan Cek File Txt Nyaa"<<endl;
	
	for(i=1; i<=j; i++)
	{	                       
		file_keluaran<<"\t\t	    		UNIVERSITAS PAKUAN"<<endl;
        file_keluaran<<"\t\t  !===========================================!"<<endl;
        file_keluaran<<"\t\t  |-------====	 Universitas Pakuan  ===---------| "<<endl;
        file_keluaran<<"\t\t  |----------------INPUT DATA-----------------| "<<endl;
        file_keluaran<<"\t\t  |___________________________________________|"<<endl;
		file_keluaran<<"\t\t\t                            "<<endl;
		file_keluaran<<"\n====================================="<<endl;
		file_keluaran<<"\nData Mahasiswa Ke-"<<i<<endl;
		file_keluaran<<"Nama\t :"<<mhs[i].nama<<endl;
		file_keluaran<<"NPM\t :"<<mhs[i].nim<<endl;
		file_keluaran<<"Program Studi\t :"<<mhs[i].prodi<<endl;
		file_keluaran<<"IPK\t :"<<mhs[i].ipk<<endl;
		file_keluaran<<"====================================="<<endl;
		file_keluaran<<"Develop By : RTX - CORE \n\n"<<endl;
	}	
	file_keluaran.close();
	
}

void sort_mhs(){
	
	int n,tmp,i;
	
	mahasiswa mhs;
	
//    input array
    cout<<"masukkan banyak data : ";
    cin>>n;
    for (int i=0; i<n; i++)
    {
        cout<<" Nama         : ";cin>>mhs.nama[i];
        cout<<" hasil Tes     = ";cin>>mhs.hasiltes[i];

        cout<<endl;
    }
	system("cls");
//    selection sort rumus


    for (i=0; i<n; i++)
               {
                       for (int j=i+1;j<n; j++)
                       {
                           if (mhs.hasiltes[i]< mhs.hasiltes[j])
                           {
                               //mhs.nama[i].swap(mhs.nama[j]);
                              
                            tmp=mhs.hasiltes[i];
                            mhs.hasiltes[i]=mhs.hasiltes[j];
                            mhs.hasiltes[j]=tmp;
                       
                        }
                       }
					   
                       
                }
//   

//    output setelah disort
	
                               
            cout<<" --------------------------------------------------------------------------"<<endl;
            cout<<" |"<<setw(5)<<" NAMA MAHASISWA "<<setw(3)<<"|"<<setw(15)<<"         HASIL TES"<<setw(20)<<"|"<<setw(10)<<"KETERANGAN"<<setw(10)<<"|";
            cout<<" \n --------------------------------------------------------------------------";
           
            for(int i=0; i<n; i++)
                  {
                     
                     
                       if(mhs.hasiltes[i]>=80 && mhs.hasiltes[i]<=100)
                    {
                    cout<<"\n |"<<setw(5)<<mhs.nama[i]<<setw(6)<<"|"<<setw(15)<<mhs.hasiltes[i]<<setw(27)<<"|"<<setw(10)<<"DITERIMA"<<setw(10)<<"|";
                    cout<<" \n --------------------------------------------------------------------------";
                    }
                   
                    if(mhs.hasiltes[i]>=70 && mhs.hasiltes[i]<80)
                    {
                    cout<<"\n |"<<setw(5)<<mhs.nama[i]<<setw(6)<<"|"<<setw(15)<<mhs.hasiltes[i]<<setw(27)<<"|"<<setw(10)<<"CADANGAN"<<setw(10)<<"|";
                    cout<<" \n --------------------------------------------------------------------------";
                    }
                   
                    if(mhs.hasiltes[i]<70)
                    {
                    cout<<"\n |"<<setw(5)<<mhs.nama[i]<<setw(6)<<"|"<<setw(15)<<mhs.hasiltes[i]<<setw(27)<<"|"<<setw(10)<<"DITOLAK"<<setw(10)<<"|";
                    cout<<" \n --------------------------------------------------------------------------\n\n";
           			
		            }
                }	
}

void mainMenu ()
{
	_strdate(date);
	//input=fopen("data_mhs.txt","a+");
	
	while(menu!=5){
	
	cout<< "\n\n\n\n\n|"<<date<<"|"<<endl;
	
			cout<<"\t\t\t\t	    	UNIVERSITAS PAKUAN"<<endl;
             cout<<"\t\t\t\t    !===========================================!"<<endl;
             cout<<"\t\t\t\t    |-------==	Universitas Pakuan  ===---------| "<<endl;
             cout<<"\t\t\t\t    |----------------MAIN MENU-----------------| "<<endl;
             cout<<"\t\t\t\t    |___________________________________________|"<<endl;
			 cout<<"\t\t\t                            "<<endl;
      
      printf("================================================");
		printf("\n\n	|| 1. List Mahasiswa ILKOM Kelas E-F 	||");
	    printf("\n\n	|| 2. Selection Srt	||");
		printf("\n\n	|| 3. Print NPM & NAME	||");
    	printf("\n\n	|| 4. Find Data	||");
		printf("\n\n	|| 5. EXIT	||");
		printf("\n\n");
	printf("================================================\n");	
	    printf("\nMasukkan Angka Pada Menu  : ");
		scanf("%d",&menu);
           
            system("cls");
            puts("");
            if(menu==1){
                list_mhsw();
                getch();
            }else if(menu==2){
                sort_mhs();
                getch();
			}else if(menu==3){
                MHS_menu();
                getch();
			}else if(menu==4){
                find_DT();
                getch();
			}else if(menu==5){
            	EXIT();
            	getch();
            }
				}
}
	
int main(int argc, char *argv[])
{
	loadingScreen("LOADING SCREEN");
	login();
   	mainMenu();
    return 0;
}



